#!/bin/bash

python /app/app.py > /app/logs.txt 2>&1
